package exceptionHandling;

class MyException extends Exception
{
	String str1;
	MyException(String str2)
	{
		str1 = str2;
	}
	public String toString()
	{
		return("My Exception Occured: " + str1);
	}
}

public class ExceptionHandling {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		try
		{
			System.out.println("Starting of try block");
			throw new MyException("This is my Error message");
		}
		catch(MyException e)
		{
			System.out.println("Catch block");
			System.out.println(e);
		}
	}

}
