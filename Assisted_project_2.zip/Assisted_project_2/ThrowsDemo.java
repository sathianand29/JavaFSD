package keywords_customException;

public class ThrowsDemo {
	
	void Division() throws ArithmeticException
	{

		int a = 78, b = 0, div ;
		div= a/b;
		System.out.println("\n The result is: " + div);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		ThrowsDemo t = new ThrowsDemo();
		try
		{
			t.Division();
		}
		catch(ArithmeticException ex)
		{
			System.out.println("\n Error: " + ex.getMessage());
		}
		System.out.println("\n End of the program");

	}

}
