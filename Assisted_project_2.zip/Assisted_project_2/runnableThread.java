package threadCreation;

public class runnableThread implements Runnable {

	public static int count = 0;
	public runnableThread() {
		
	}
	public void run() {
		while(runnableThread.count <=10) {
			try {
				System.out.println("Expl thread : "+ (++runnableThread.count));
				Thread.sleep(100);
			}
			catch(InterruptedException iex){
				System.out.println("Exception in thread: "+ iex.getMessage());
			}
		}
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.out.println("Starting main thread...");
		runnableThread rt = new runnableThread();
		Thread t = new Thread(rt);
		t.start();
		
		while(runnableThread.count <=10) {
			
			try {
				System.out.println("main thread : "+ (++runnableThread.count));
				Thread.sleep(100);
			}
			catch(InterruptedException iex){
				System.out.println("Exception in main thread: "+ iex.getMessage());
			}
		}
		System.out.println("End of main thread..");

	}

}
