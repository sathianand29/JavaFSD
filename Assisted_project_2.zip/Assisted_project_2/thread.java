package threadCreation;

public class thread extends Thread {
	
	public void run()
	{
		System.out.println("concurrent thread started running...");
	
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		thread t = new thread();
		t.start();

	}

}
