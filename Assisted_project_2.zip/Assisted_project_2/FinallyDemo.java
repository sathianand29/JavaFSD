package keywords_customException;

public class FinallyDemo {
	
	public static void main(String[] args) 
	{
		int a = 78, b = 0, div=0 ;
		try
		{
			div = a/b;
		}
		catch(ArithmeticException ex)
		{
				System.out.println("\n Error: " + ex.getMessage());
		}
		finally
		{
			System.out.println("\n The result is: " + div );
		}
	}

}
