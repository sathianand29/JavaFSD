package keywords_customException;

public class throwDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int a = 78, b = 0, div ;
		try
		{
			if(b== 0)
			{
				throw(new  ArithmeticException("Can't divide by zero!"));
			}
			else
			{
				div= a/b;
				System.out.println("\n The result is: " + div);
			}
		}
		catch(ArithmeticException ex)
		{
				System.out.println("\n Error: " + ex.getMessage());
		}
		System.out.println("\n End of the program");

	}

}
