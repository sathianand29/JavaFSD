package sorting_searching;

import java.util.*;

public class LinearSearch {
	
	public static int linear(int[] arr, int val)
	{
		int n= arr.length;
		for(int i= 0; i < n; i++)
		{
			if(arr[i] == val)
				return i;
		}
		return -1;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int searchValue, res;
		int[] arr = { 20, 30, 50, 10, 40};
		Arrays.sort(arr);
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the elemnets to be searched");
		searchValue = sc.nextInt();
		
		res = linear(arr, searchValue);
		
		if(res == -1)
		{
			System.out.println("Element is not present in the array");
		}
		else {
			System.out.println("Element found at "+res+ " and the search key is "+arr[res]);
		}
		
		

	}

}
