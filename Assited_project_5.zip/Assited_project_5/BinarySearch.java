package sorting_searching;

import java.util.*;

public class BinarySearch {
	
	public static void
	Search(int[] arr, int start, int key, int len)
	{
		int mid = (start+len) / 2;
		while(start <= len)
		{
			if(arr[mid] < key)
			{
				start = mid + 1;
			}
			else if(arr[mid] == key)
			{
				System.out.println("Element is found at index "+ mid);
				break;
			}
			else
			{
				len = mid - 1;
				
			}
			mid = (start+len) / 2;
		}
		if(start > len)
		{
			System.out.println("Elements is not found");
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int arr[] = { 3, 6, 9, 12, 15};
		Arrays.sort(arr);
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the element to be searched");
		int key = sc.nextInt();
		
		int n = arr.length;
		Search(arr, 0, key, n);

	}

}
