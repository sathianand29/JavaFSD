package sorting_searching;

public class InsertionSort {
	
	public static void sort(int[] arr)
	{
	    int len = arr.length;
	    for(int j=1;j<len;j++)
	    {
	    int key = arr[j];
	    int i=j-1;
	    while((i>-1) && (arr[i]>key))
	    {

	        arr[i+1]=arr[i];
	        i--;
	    }
	    arr[i+1]=key;
	   }

	}
	
public static void main(String[] args) {
		
		int[] arr = {25,20,15,5,10};
		sort(arr);
		for(int i=0; i<arr.length; i++)
		{
			System.out.print(arr[i] + " ");
		}
		
	}

}
