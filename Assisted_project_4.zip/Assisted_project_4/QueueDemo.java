package arrays_lists;
import java.util.Queue;
import java.util.LinkedList;

public class QueueDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Queue<String> locations = new LinkedList<>();
		locations.add("Delhi");
		locations.add("Mumbai");
		locations.add("Kolkata");
		locations.add("Bangalore");
		locations.add("Chennai");
		
		System.out.println("Queue is : " + locations);
		System.out.println("Head of Queue : " + locations.peek());
		locations.remove();
		System.out.println("After removing Head of Queue : " + locations);
		System.out.println("Size of Queue : " + locations.size());

	
	}

}
