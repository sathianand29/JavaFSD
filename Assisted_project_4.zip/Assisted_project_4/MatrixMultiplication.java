package arrays_lists;

public class MatrixMultiplication {
	
	public static void main(String[] args) {
		int r1 = 2, r2 = 3, c1= 3, c2 = 2;
		int[][] FirstMatrix = {{3, -2, 5}, {3, 0, 4}};
		int[][] SecondMatrix = {{2, 3}, {-9, 0}, {0, 4}};
		int[][] Product  = multiply(FirstMatrix, SecondMatrix, r1, c1, c2);
		displayProduct(Product);
		
	}
	public static int[][] multiply(int[][] firstMatrix, int[][] secondMatrix, int r1, int c1, int c2)
	{
		int[][] Product = new int[r1][c2];
		for(int i=0; i< r1; i++)
		{
			for(int j = 0; j < c2; j++)
			{
				for(int k = 0; k < c1; k++)
				{
					Product[i][j] += firstMatrix[i][k] * secondMatrix[k][j] ;
					
				}
			}
		}
		return Product;
	}
	public static void displayProduct(int[][] Product) {
		System.out.println("Product of 2 matrices is: ");
		for(int[] row : Product)
		{
			for(int column : row)
			{
				System.out.print(column + "  ");
			}
			System.out.println();
		}
	}

}
