package arrays_lists;

public class Range {

	public static void rangeQuery(int[] arr, int l, int r, int n)
	{
		int sum = 0;
		if(l >= 0 && l <= r && r < n)
		{
			for(int i = l; i <= r; i++)
			{
				sum += arr[i];
			}
			System.out.println(sum);
		}
		else 
			System.out.println("Invalid Range!");
		
		
	}
	public static void main(String[] args) {
		int[] arr = { 3, 7, 2, 5, 8, 9};
		int n = arr.length;
		rangeQuery(arr, 0, 5, n);
		rangeQuery(arr, 3, 5, n);
		rangeQuery(arr, 2, 4, n);
		rangeQuery(arr, 2, 6, n);
		
		
	}
}
