package arrays_lists;
import java.util.Scanner;

public class Order_Statistics
{
	
		public static void main(String[] args)
		{
			// TODO Auto-generated method stub
			Scanner sc = new Scanner(System.in);
			System.out.println("Enter array size: ");
			int n = sc.nextInt();
			int arr[] = new int[n];
			int temp;
			System.out.println("Enter array elements: ");
			for(int i=0;i<n;i++) 
			{
				arr[i]=sc.nextInt();
			}
			for(int i=0;i<n;i++)
			{
				for(int j=i+1;j<n;j++) 
				{
					if(arr[i]>arr[j]) 
					{
						temp = arr[i];
						arr[i]=arr[j];
						arr[j]=temp;
					}
				}
			}
			System.out.println("Fourth smallest element is: "+arr[3]);
		}
}
