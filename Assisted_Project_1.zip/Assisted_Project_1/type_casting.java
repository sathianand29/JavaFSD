package assisted_practice1;

public class type_casting {
	
	public static void main(String[] args) {
		
		System.out.println("Implicit type casting:");
		char a = 'A';
		System.out.println("Value of a is " + a);
		
		int b = a;
		System.out.println("Value of b is " + b);
		
		float c = a;
		System.out.println("Value of c is " + c);
		
		double d = a;
		System.out.println("Value of d is " + d);
		
		System.out.println("\n");
		
		System.out.println("Explicit type casting:");
		
		double x = 23.67;
		System.out.println("Value of x is " + x);
		
		float y = (float)x;
		System.out.println("Value of y is " + y);
		
		int z = (int)x;
		System.out.println("Value of z is " + z);
		
	
	}

}