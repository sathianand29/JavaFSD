package accessSpecifiers2;
import accessSpecifiers.*;

public class accessSpecifiers3 extends protectedAccessSpecifier{
	public static void main(String[] args) {
		accessSpecifiers3 obj = new accessSpecifiers3 ();   
	       obj.display();  
	}

}
