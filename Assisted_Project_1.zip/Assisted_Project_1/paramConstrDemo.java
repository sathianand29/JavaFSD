package constructor;

public class paramConstrDemo {
public static void main(String[] args) {

	Std std1=new Std(3,"Alex");
	Std std2=new Std(7,"Angel");
	std1.display();
	std2.display();
		}
}
