package accessSpecifiers2;
import accessSpecifiers.*;

public class accessSpecifiers4 {
public static void main(String[] args) {
		
		publicAccessSpecifier obj = new publicAccessSpecifier(); 
        obj.display();  
		
	}


}
