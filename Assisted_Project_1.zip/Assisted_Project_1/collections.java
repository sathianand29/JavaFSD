package collection;
import java.util.*;

public class collections {

	public static void main(String[] args) {
		//Arraylist
		System.out.println("Arraylist");
		
		ArrayList<String> city = new ArrayList<String>();
		
		city.add("Chennai");
		city.add("Mumbai");
		
		System.out.println(city);
		
		//vector
		System.out.println("\n");
		System.out.println("Vector");
		
		Vector<Integer> vec = new Vector<Integer>();
		
		vec.add(12);
		vec.add(54);
		vec.add(87);
		
		System.out.println(vec);
		
		//LinkedList
		System.out.println("\n");
		System.out.println("LinkedList");
		
		LinkedList<String> name = new LinkedList<String>();
		
		name.add("Alexa");
		name.add("Siri");
		Iterator<String> itr=name.iterator();  
	      while(itr.hasNext()){  
	       System.out.println(itr.next());  
	       
	     //Hashset
	      System.out.println("\n");
	      System.out.println("Hashset");
	      
	      HashSet<Integer> set = new HashSet<Integer>();
	      
	      set.add(101);
	      set.add(102);
	      set.add(103);
	      set.add(104);
	      
	      System.out.println(set);
	      
	      //LinkedHashSet
	      System.out.println("\n");
	       System.out.println("LinkedHashSet");
	       LinkedHashSet<Integer> set2=new LinkedHashSet<Integer>();  
	       set2.add(11);  
	       set2.add(13);  
	       set2.add(12);
	       set2.add(14);	       
	       System.out.println(set2);

	      }
	}
}
