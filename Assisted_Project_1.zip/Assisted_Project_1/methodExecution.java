package Methods;


public class methodExecution {

	public int multiplynumbers(int a, int b) {
		int x = a*b;
		return x;
	}
	public static void main(String[] args) {
		methodExecution b = new methodExecution();
		int ans =b.multiplynumbers(5,4);
		System.out.println("Multiplication is: "+ans);
	}
}
