package accessSpecifiers;

public class publicAccessSpecifier {
	public void display() 
    { 
        System.out.println("This is Public Access Specifiers"); 
    } 


}
